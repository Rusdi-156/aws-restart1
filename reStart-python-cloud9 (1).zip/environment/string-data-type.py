myString="this is a string"
print(myString)
a=print(type(myString))

print("{} is of {} data type.". format(myString,a))

firstString="Water"
secondString="fall"
thridString=firstString+secondString
print(thridString)

name=input("what is your name?")
print(name)
animal=input("what is your favorite animal?")
print(animal)
color=input("what is your favorite color?")
print(color)

print("{}, you like a {} {}".format(name,animal,color))
