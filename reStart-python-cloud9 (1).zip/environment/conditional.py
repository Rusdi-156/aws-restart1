# userReply=input("Do you to ship a package? enter (YES or NO)")

# if userReply.lower() == "yes" or "y":
#     print("We can help you that package!")
# elif userReply.lower() == "no" or "n":
#     print("Please come back when you need to ship a package. Thank you")
# else:
#     print("EROR. Pleas enter YES or No")
    

print("Would you like to buy stamps, buy an envelope, or make a copy?")
userReply = input("Enter stamps, envelope, or copy..." )
if userReply.lower() == "stamps":
    print("We have many stamp designs to choose from.")
    
elif userReply.lower() == "envelope":
    print("We have many envelope sizes to choose from.")

elif userReply.lower() == "copy":
    print("How many copies would you like? (Enter a number) ")
    copi = input()
    copies = int(copi)
    for x in range (0, copies):
        print(x)
    print("Here are {} copies.".format(copies))

else:
    print("OK, see you.")

# print("Would you like to buy stamps, buy an envelope, or make a copy? (Enter stamps, envelope, or copy)")
# userReply= input()
# match userReply:for
#     case "stamps":
#         print ("We have many stamp designs to choose from.")
#     case "envelope":
#         print("We have many envelope sizes to choose from.")
#     case "copy":
#         copies=input("How many copies would you like? (Enter a number)")
#         for x in range (0, copies):
#             print(x + "copy")
#         print("This is it")
