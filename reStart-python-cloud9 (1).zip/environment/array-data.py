# MyFruitList=['apple','banana','manggo']
# print(MyFruitList)
# print(type(MyFruitList))
# print(MyFruitList[0])
# print(MyFruitList[1])
# print(MyFruitList[2])
# print(' ')

# import array as arr

# myArr = arr.array('i', [1,2,3])
# print(myArr)
# print(str(myArr[1])+str(myArr[2])+str(myArr[0])+str(myArr[-2]))
# myArr[2] = 9
# print("myArr[2] = 9")
# print(myArr)
# print(str(myArr[1])+str(myArr[2])+str(myArr[0])+str(myArr[-2]))
# print(type(myArr))
# print(' ')

# myChar=arr.array('u', ['a', 'b', 'c', 'd', 'e'])
# print(myChar)
# print(myChar[1] + myChar[2] + myChar[4]+ myChar[0]+ myChar[-1]) 
# print(type(myArr))
# print(' ')

# group = [
#     ["Yusuf", "Adnan", "Hakim"],
#     ["Abu", "Ummi", "Ami"]
# ]

# print(group[1][2])

# aaa=('apple','banana','manggo');
# print(aaa);
# print(type(aaa));

# aaa[1] = 'watermelon'

# print("MyFavoriteFruitDictionary")
# MFFD = {
#   "Akua" : "Apple",
#   "Saanvi" : "Banana",
#   "Paulo" : "Pineapple"
# }

# print(MFFD)
# print(MFFD["Akua"])
# print(MFFD["Saanvi"])
# print(MFFD["Paulo"])

# myset={1,2,2,3,3,4,5,1}
# print(myset)