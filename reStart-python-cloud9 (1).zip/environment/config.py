MMTL=[45,2987,1.22,True,"My dog is on your bed.","45"]
print("=================================================")
for item in MMTL:
    # print("{} is of the data type {}".format(item,type(item)))
    print(" ")
    print(f"{item} is of the data type {type(item)}")
print(" ")
print("=================================================")