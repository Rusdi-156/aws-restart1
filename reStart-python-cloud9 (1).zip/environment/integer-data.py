myinteger=("This is a Integer")
print(myinteger)
print('=======================================')

firststring     = input("nama pertama....")
secondstring    = input("nama kedua.....") 
thridstring     = firststring + " " + secondstring
print(thridstring)
print('=======================================')

name=input()
print(name)