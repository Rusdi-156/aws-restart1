import random

print("=============================================================================")
print("                  *Welcome to Guess the Number!*                             ")
print("The rules are simple. I will think of a number, and you will try to guess it.")
print("=============================================================================")


isGuessRight=False
while isGuessRight != True:
    number=random.randint(1,10)
    guess=input("Guess a number between 1 to 10 is ")
    if int(guess) == number:
        print("You guessed {}. That is correct! You win!".format(guess))
        isGuessRight=True
    else:
        print("Count to 3!")
        for x in range (1, 4):
            print(x)
        print("You guessed {}. Sorry, that isn't it. Try again.".format(guess))
        


