print("Hello, World!!!!!!!!")
print('Ketikkan Namamu:....')