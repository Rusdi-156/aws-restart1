# x=5
# y=5.0

# print(x==y)

userInput=(input("Tebak angka 1-9! " ))

if userInput == "9":
    print("BENAR angka "+userInput)
else:
    print("SALAH......")